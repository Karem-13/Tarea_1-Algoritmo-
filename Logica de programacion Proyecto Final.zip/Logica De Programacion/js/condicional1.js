
    function validarEdad() {
      const edad = parseInt(document.getElementById("edad").value);
      let mensaje = "";

      if (edad >= 0 && edad <= 12) {
        mensaje = "Eres un niño.";
      } else if (edad <= 17) {
        mensaje = "Eres un adolescente.";
      } else if (edad <= 59) {
        mensaje = "Eres un adulto.";
      } else if (edad >= 60) {
        mensaje = "Eres un adulto mayor.";
      } else {
        mensaje = "Edad inválida.";
      }

      document.getElementById("resultado").innerHTML = `<strong>Resultado:</strong> ${mensaje}`}