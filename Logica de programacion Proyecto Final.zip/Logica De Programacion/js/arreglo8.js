function factorial(n) {
      if (n < 0) return "No definido";
      let f = 1;
      for (let i = 1; i <= n; i++) {
        f *= i;
      }
      return f;
    }

    function mostrarFactoriales() {
      const numeros = [
        Number(document.getElementById('n1').value),
        Number(document.getElementById('n2').value),
        Number(document.getElementById('n3').value),
        Number(document.getElementById('n4').value),
      ];

      if (numeros.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todos los campos correctamente.';
        return;
      }

      let salida = '';
      numeros.forEach(n => {
        salida += `El factorial de ${n} es ${factorial(n)}<br>`;
      });

      document.getElementById('resultado').innerHTML = salida;
    }

    function limpiar() {
      for (let i = 1; i <= 4; i++) {
        document.getElementById('n' + i).value = '';
      }
      document.getElementById('resultado').textContent = '';
    }