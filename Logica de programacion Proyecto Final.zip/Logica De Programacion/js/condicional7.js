 function saludar() {
      const hora = parseInt(document.getElementById('hora').value);
      let mensaje = "";

      if (!isNaN(hora) && hora >= 0 && hora <= 23) {
        if (hora <= 11) {
          mensaje = "☀ Buenos días";
        } else if (hora <= 17) {
          mensaje = "🌤 Buenas tardes";
        } else {
          mensaje = "🌙 Buenas noches";
        }
      } else {
        mensaje = "⛔ Ingresa una hora válida entre 0 y 23.";
      }

      document.getElementById('salida').textContent = mensaje;
    }

    function limpiar() {
      document.getElementById('hora').value = "";
      document.getElementById('salida').textContent = "";
    }