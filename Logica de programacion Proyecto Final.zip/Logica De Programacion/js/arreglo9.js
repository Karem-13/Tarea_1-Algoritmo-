function copiarPares() {
      const arregloOriginal = [
        Number(document.getElementById('n1').value),
        Number(document.getElementById('n2').value),
        Number(document.getElementById('n3').value),
        Number(document.getElementById('n4').value),
        Number(document.getElementById('n5').value),
        Number(document.getElementById('n6').value),
      ];

      if (arregloOriginal.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todos los campos correctamente.';
        return;
      }

      const arregloPares = arregloOriginal.filter(num => num % 2 === 0);

      document.getElementById('resultado').innerHTML = `
        Arreglo original: [${arregloOriginal.join(', ')}]<br>
        Arreglo con pares: [${arregloPares.join(', ')}]
      `;
    }

    function limpiar() {
      for (let i = 1; i <= 6; i++) {
        document.getElementById('n' + i).value = '';
      }
      document.getElementById('resultado').textContent = '';
    }