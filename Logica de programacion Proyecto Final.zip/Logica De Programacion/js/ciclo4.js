
    function calcularFactorial() {
      const n = parseInt(document.getElementById("num4").value);
      if (isNaN(n) || n < 0) {
        document.getElementById("res4").innerText = "Por favor ingresa un número válido (0 o mayor).";
        return;
      }

      let factorial = 1;
      for (let i = 1; i <= n; i++) {
        factorial *= i;
      }

      document.getElementById("res4").innerText = `El factorial de ${n} es: ${factorial}`;
    }

    function limpiarEjercicio4() {
      document.getElementById("num4").value = '';
      document.getElementById("res4").innerText = '';
    }

