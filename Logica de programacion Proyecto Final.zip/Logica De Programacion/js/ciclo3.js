function sumarN() {
  const n = parseInt(document.getElementById("num3").value);
  let suma = 0;
  for (let i = 1; i <= n; i++) suma += i;
  document.getElementById("res3").innerText = `La suma de los primeros ${n} números es: ${suma}`;
}

function limpiarEjercicio3() {
  document.getElementById("num3").value = '';
  document.getElementById("res3").innerText = '';
}
