 function compararTextos() {
      const texto1 = document.getElementById('texto1').value.trim();
      const texto2 = document.getElementById('texto2').value.trim();
      const res = document.getElementById('resultado');

      if (texto1 === '' || texto2 === '') {
        res.textContent = 'Por favor, completa ambos textos.';
        return;
      }

      if (texto1.length > texto2.length) {
        res.textContent = 'El primer texto tiene más letras.';
      } else if (texto2.length > texto1.length) {
        res.textContent = 'El segundo texto tiene más letras.';
      } else {
        res.textContent = 'Ambos textos tienen la misma cantidad de letras.';
      }
    }

    function limpiar() {
      document.getElementById('texto1').value = '';
      document.getElementById('texto2').value = '';
      document.getElementById('resultado').textContent = '';
    }