    function sumarArreglos() {
      const arr1 = [
        Number(document.getElementById('a1_1').value),
        Number(document.getElementById('a1_2').value),
        Number(document.getElementById('a1_3').value),
        Number(document.getElementById('a1_4').value),
      ];

      const arr2 = [
        Number(document.getElementById('a2_1').value),
        Number(document.getElementById('a2_2').value),
        Number(document.getElementById('a2_3').value),
        Number(document.getElementById('a2_4').value),
      ];

      if (arr1.some(isNaN) || arr2.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todos los campos correctamente.';
        return;
      }

      const suma = arr1.map((num, i) => num + arr2[i]);

      document.getElementById('resultado').innerHTML = `
        Arreglo 1: [${arr1.join(', ')}]<br>
        Arreglo 2: [${arr2.join(', ')}]<br>
        Suma: [${suma.join(', ')}]
      `;
    }

    function limpiar() {
      const ids = ['a1_1','a1_2','a1_3','a1_4','a2_1','a2_2','a2_3','a2_4'];
      ids.forEach(id => document.getElementById(id).value = '');
      document.getElementById('resultado').textContent = '';
    }
