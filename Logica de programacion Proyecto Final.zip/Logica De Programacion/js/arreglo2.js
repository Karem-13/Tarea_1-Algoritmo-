 function contarImpares() {
      const numeros = [
        Number(document.getElementById('n1').value),
        Number(document.getElementById('n2').value),
        Number(document.getElementById('n3').value),
        Number(document.getElementById('n4').value),
        Number(document.getElementById('n5').value),
      ];

      if (numeros.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todos los campos correctamente.';
        return;
      }

      let impares = numeros.filter(n => n % 2 !== 0);
      document.getElementById('resultado').textContent = `Hay ${impares.length} número(s) impar(es): ${impares.join(', ')}`;
    }

    function limpiar() {
      for (let i = 1; i <= 5; i++) {
        document.getElementById('n' + i).value = '';
      }
      document.getElementById('resultado').textContent = '';
    }