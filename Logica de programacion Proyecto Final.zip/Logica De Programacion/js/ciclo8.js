function pedirNombres() {
      let nombre;
      let contador = 0;
      while (true) {
        nombre = prompt("Escribe un nombre (escribe 'Messi' para detener):");
        if (nombre === null) break;
        if (nombre.trim().toLowerCase() === "messi") break;
        contador++;
      }
      document.getElementById("res8").innerText = `Se ingresaron ${contador} nombres antes de escribir 'Messi'.`;
    }

    function limpiarEjercicio8() {
      document.getElementById("res8").innerText = '';
    }
