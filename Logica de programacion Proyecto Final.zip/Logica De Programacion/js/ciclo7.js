 function fibonacci() {
      const n = parseInt(document.getElementById("num7").value);
      if (isNaN(n) || n <= 0) {
        document.getElementById("res7").innerText = "Por favor ingresa un número mayor a 0.";
        return;
      }

      let a = 0, b = 1, resultado = "0";
      let i = 1;

      while (i < n) {
        resultado += ", " + b;
        let temp = a + b;
        a = b;
        b = temp;
        i++;
      }

      document.getElementById("res7").innerText = `Fibonacci (${n} términos): ${resultado}`;
    }

    function limpiarEjercicio7() {
      document.getElementById("num7").value = '';
      document.getElementById("res7").innerText = '';
    }