function mostrarDivisores() {
      const n = parseInt(document.getElementById("num6").value);
      if (isNaN(n) || n <= 0) {
        document.getElementById("res6").innerText = "Ingresa un número válido mayor a 0.";
        return;
      }

      let i = 1;
      let resultado = "Divisores: ";
      while (i <= n) {
        if (n % i === 0) {
          resultado += i + " ";
        }
        i++;
      }

      document.getElementById("res6").innerText = resultado;
    }

    function limpiarEjercicio6() {
      document.getElementById("num6").value = '';
      document.getElementById("res6").innerText = '';
    }