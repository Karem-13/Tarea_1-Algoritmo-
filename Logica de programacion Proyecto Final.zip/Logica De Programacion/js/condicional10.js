    function descuentoMembresia() {
      var tieneMembresia = document.getElementById("membresia").value === "si";
      var compra = parseFloat(document.getElementById("compra").value);
      var resultado = document.getElementById("resultado10");

      if (isNaN(compra) || compra <= 0) {
        resultado.innerText = "Por favor ingresa un valor de compra válido.";
        resultado.style.color = "red";
        return;
      }

      var descuento = 0;
      var iva = 0;

      if (tieneMembresia && compra > 50) {
        descuento = 0.30;
        iva = 0.15;
      } else {
        descuento = 0.05;
        iva = 0.10;
      }

      var subtotal = compra - (compra * descuento);
      var total = subtotal + (subtotal * iva);

      resultado.innerText = `Total a pagar: $${total.toFixed(2)} (Descuento ${descuento * 100}%, IVA ${iva * 100}%)`;
      resultado.style.color = "green";
    }

    function limpiar() {
      document.getElementById("membresia").value = "si";
      document.getElementById("compra").value = "";
      document.getElementById("resultado10").innerText = "";
    }

    function regresar() {
      window.location.href = "../pages/condicionales.html";
    }