 function verificarPalindromo() {
      const texto = document.getElementById('palabra').value;
      const res = document.getElementById('resultado');

      if (texto.trim() === '') {
        res.textContent = 'Por favor, ingresa una palabra o frase.';
        return;
      }

      const limpio = texto.toLowerCase().replace(/[^a-z0-9]/gi, '');
      const invertido = limpio.split('').reverse().join('');

      if (limpio === invertido) {
        res.textContent = '✅ Es un palíndromo.';
      } else {
        res.textContent = '❌ No es un palíndromo.';
      }
    }

    function limpiar() {
      document.getElementById('palabra').value = '';
      document.getElementById('resultado').textContent = '';
    }