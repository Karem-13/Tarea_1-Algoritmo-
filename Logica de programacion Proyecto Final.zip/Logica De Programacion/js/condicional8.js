function calcularBono() {
  let hijos = parseInt(prompt("¿Cuántos hijos tienes?"));
  let trabajo = prompt("¿Tienes trabajo? (sí/no)").toLowerCase();
  let bono = 0;

  if (hijos > 0 && trabajo === "sí") {
    bono = hijos * 50;
  } else if (hijos > 0 && trabajo === "no") {
    bono = hijos * 30;
  }

  alert("Tu bono es: $" + bono);
}