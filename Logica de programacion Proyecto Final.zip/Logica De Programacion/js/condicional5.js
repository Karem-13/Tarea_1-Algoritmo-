  function ejercicio5() {
    const temp = parseFloat(document.getElementById("temp5").value);
    const res = document.getElementById("resultado5");

    if (isNaN(temp)) {
      res.textContent = "Ingresa una temperatura válida.";
      return;
    }

    if (temp < 15) {
      res.textContent = "Hace frío.";
    } else if (temp <= 25) {
      res.textContent = "Está templado.";
    } else {
      res.textContent = "Hace calor.";
    }
  }