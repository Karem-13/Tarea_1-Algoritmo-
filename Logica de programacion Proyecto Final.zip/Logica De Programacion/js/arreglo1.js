 function calcularPromedio() {
      const nums = [
        Number(document.getElementById('n1').value),
        Number(document.getElementById('n2').value),
        Number(document.getElementById('n3').value),
        Number(document.getElementById('n4').value),
        Number(document.getElementById('n5').value)
      ];

      if (nums.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Por favor, completa todos los campos.';
        return;
      }

      const suma = nums.reduce((a, b) => a + b, 0);
      const promedio = suma / nums.length;

      document.getElementById('resultado').textContent = `El promedio es: ${promedio.toFixed(2)}`;
    }

    function limpiar() {
      for (let i = 1; i <= 5; i++) {
        document.getElementById(`n${i}`).value = '';
      }
      document.getElementById('resultado').textContent = '';
    }