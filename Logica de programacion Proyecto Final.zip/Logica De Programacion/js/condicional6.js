
   function mostrarSaludo() {
      const nombre = document.getElementById('nombre').value;
      const genero = document.getElementById('genero').value;
      let mensaje = "";

      if (nombre && genero) {
        mensaje = (genero === 'F') ? `Bienvenida, ${nombre}` : `Bienvenido, ${nombre}`;
      } else {
        mensaje = "Por favor ingresa todos los datos.";
      }

      document.getElementById('salida').textContent = mensaje;
    }

    function limpiar() {
      document.getElementById('nombre').value = "";
      document.getElementById('genero').value = "";
      document.getElementById('salida').textContent = "";
    }