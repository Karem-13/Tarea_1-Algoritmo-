    function numeroMayor() {
      const n1 = parseFloat(document.getElementById("n1").value);
      const n2 = parseFloat(document.getElementById("n2").value);
      const n3 = parseFloat(document.getElementById("n3").value);
      const n4 = parseFloat(document.getElementById("n4").value);

      if (isNaN(n1) || isNaN(n2) || isNaN(n3) || isNaN(n4)) {
        document.getElementById("resultado2").textContent = "Por favor, ingresa los 4 números.";
        return;
      }

      const mayor = Math.max(n1, n2, n3, n4);
      document.getElementById("resultado2").textContent = `El número mayor es: ${mayor}`;
    }

    function limpiarCampos() {
      document.getElementById("n1").value = "";
      document.getElementById("n2").value = "";
      document.getElementById("n3").value = "";
      document.getElementById("n4").value = "";
      document.getElementById("resultado2").textContent = "Se mostrará el número mayor aquí.";
    }