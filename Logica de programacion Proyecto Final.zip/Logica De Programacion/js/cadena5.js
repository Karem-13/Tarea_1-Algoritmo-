function mostrarIniciales() {
      const nombre = document.getElementById('nombre').value.trim();
      const res = document.getElementById('resultado');

      if (nombre === '') {
        res.textContent = 'Por favor, ingresa un nombre completo.';
        return;
      }

      const palabras = nombre.split(/\s+/);
      let iniciales = palabras.map(palabra => palabra[0].toUpperCase()).join('');
      res.textContent = `Iniciales: ${iniciales}`;
    }

    function limpiar() {
      document.getElementById('nombre').value = '';
      document.getElementById('resultado').textContent = '';
    }