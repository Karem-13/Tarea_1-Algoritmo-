function verificarDia() {
      const dia = document.getElementById("dia").value.trim().toLowerCase();
      const resultado = document.getElementById("resultado4");

      const entreSemana = ["lunes", "martes", "miércoles", "miercoles", "jueves", "viernes"];
      const finDeSemana = ["sábado", "sabado", "domingo"];

      if (finDeSemana.includes(dia)) {
        resultado.textContent = "Es fin de semana.";
      } else if (entreSemana.includes(dia)) {
        resultado.textContent = "Es un día entre semana.";
      } else {
        resultado.textContent = "Día no válido. Por favor, ingresa un día correcto.";
      }
    }

    function limpiarCampos() {
      document.getElementById("dia").value = "";
      document.getElementById("resultado4").textContent =
        "Aquí se mostrará si es fin de semana o entre semana.";
    }