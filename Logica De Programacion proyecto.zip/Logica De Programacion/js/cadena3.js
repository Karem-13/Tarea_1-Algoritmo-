function invertirCadena() {
      const texto = document.getElementById('cadena').value;
      const res = document.getElementById('resultado');

      if (texto.trim() === '') {
        res.textContent = 'Por favor, ingresa una cadena.';
        return;
      }

      const invertida = texto.split('').reverse().join('');
      res.textContent = `Cadena invertida: ${invertida}`;
    }

    function limpiar() {
      document.getElementById('cadena').value = '';
      document.getElementById('resultado').textContent = '';
    }