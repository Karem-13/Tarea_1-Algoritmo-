function concatenarPalabras() {
      const palabras = [
        document.getElementById('p1').value.trim(),
        document.getElementById('p2').value.trim(),
        document.getElementById('p3').value.trim(),
        document.getElementById('p4').value.trim(),
        document.getElementById('p5').value.trim(),
      ];

      if (palabras.some(p => p === '')) {
        document.getElementById('resultado').textContent = 'Por favor, completa todas las palabras.';
        return;
      }

      const frase = palabras.join(' ');
      document.getElementById('resultado').textContent = `Frase concatenada: "${frase}"`;
    }

    function limpiar() {
      ['p1', 'p2', 'p3', 'p4', 'p5'].forEach(id => {
        document.getElementById(id).value = '';
      });
      document.getElementById('resultado').textContent = '';
    }

    