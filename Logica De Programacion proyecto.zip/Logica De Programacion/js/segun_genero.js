
function saludoGenero() {
  var nombre = document.getElementById("nombre").value.trim();
  var genero = document.getElementById("genero").value;
  var resultado = document.getElementById("resultado");

  if (nombre === "" || genero === "") {
    resultado.innerText = "Por favor ingresa tu nombre y selecciona tu género.";
    resultado.style.color = "red";
  } else {
    var saludo = (genero === "F") ? "Bienvenida" : "Bienvenido";
    resultado.innerText = saludo + " " + nombre + "!";
    resultado.style.color = "green";
  }
}

function limpiar() {
  document.getElementById("nombre").value = "";
  document.getElementById("genero").value = "";
  document.getElementById("resultado").innerText = "";
}

