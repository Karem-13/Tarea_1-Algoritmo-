function buscarValor() {
      const arreglo = [
        Number(document.getElementById('a1').value),
        Number(document.getElementById('a2').value),
        Number(document.getElementById('a3').value),
        Number(document.getElementById('a4').value),
        Number(document.getElementById('a5').value)
      ];

      const valorBuscar = Number(document.getElementById('buscar').value);

      if (arreglo.some(isNaN) || isNaN(valorBuscar)) {
        document.getElementById('resultado').textContent = 'Por favor, completa todos los campos correctamente.';
        return;
      }

      const encontrado = arreglo.includes(valorBuscar);

      document.getElementById('resultado').textContent = 
        encontrado 
          ? `✅ El número ${valorBuscar} SÍ se encuentra en el arreglo.` 
          : `❌ El número ${valorBuscar} NO está en el arreglo.`;
    }

    function limpiar() {
      ['a1', 'a2', 'a3', 'a4', 'a5', 'buscar'].forEach(id => {
        document.getElementById(id).value = '';
      });
      document.getElementById('resultado').textContent = '';
    }