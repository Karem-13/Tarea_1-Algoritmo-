  function dividirOracion() {
      const oracion = document.getElementById('oracion').value.trim();
      const res = document.getElementById('resultado');

      if (oracion === '') {
        res.textContent = 'Por favor, escribe una oración.';
        return;
      }

      const palabras = oracion.split(/\s+/);

      let html = '<ul>';
      for (let i = 0; i < palabras.length; i++) {
        html += `<li>${palabras[i]}</li>`;
      }
      html += '</ul>';

      res.innerHTML = html;
    }

    function limpiar() {
      document.getElementById('oracion').value = '';
      document.getElementById('resultado').textContent = '';
    }