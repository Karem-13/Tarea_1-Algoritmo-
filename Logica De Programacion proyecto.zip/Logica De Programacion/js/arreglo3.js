function contarMayores() {
      const edades = [
        Number(document.getElementById('e1').value),
        Number(document.getElementById('e2').value),
        Number(document.getElementById('e3').value),
        Number(document.getElementById('e4').value),
        Number(document.getElementById('e5').value),
        Number(document.getElementById('e6').value),
      ];

      if (edades.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todas las edades correctamente.';
        return;
      }

      const mayores = edades.filter(e => e >= 18);
      document.getElementById('resultado').textContent =
        `Se encontraron ${mayores.length} mayor(es) de edad: ${mayores.join(', ')}`;
    }

    function limpiar() {
      for (let i = 1; i <= 6; i++) {
        document.getElementById('e' + i).value = '';
      }
      document.getElementById('resultado').textContent = '';
    }