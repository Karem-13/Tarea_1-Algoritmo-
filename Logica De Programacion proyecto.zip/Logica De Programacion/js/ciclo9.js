function sumarPositivos() {
      let suma = 0;
      let numero;

      while (true) {
        let entrada = prompt("Ingresa un número (negativo para terminar):");
        if (entrada === null) break; // cancelar
        numero = parseFloat(entrada);

        if (isNaN(numero)) {
          alert("Por favor, ingresa un número válido.");
          continue;
        }

        if (numero < 0) break;

        suma += numero;
      }

      document.getElementById("res9").innerText = `La suma total es: ${suma}`;
    }

    function limpiarEjercicio9() {
      document.getElementById("res9").innerText = '';
    }