 function contarA() {
  const texto = document.getElementById('texto').value.toLowerCase();
  const res = document.getElementById('resultado');

  if (texto === '') {
    res.textContent = 'Por favor, ingresa un texto.';
    return;
  }

  let contador = 0;
  for (let letra of texto) {
    if (letra === 'a') {
      contador++;
    }
  }

  const plural = (contador === 1) ? 'vez' : 'veces';
  res.textContent = `La letra "a" se repite ${contador} ${plural}.`;
}

function limpiar() {
  document.getElementById('texto').value = '';
  document.getElementById('resultado').textContent = '';
}
