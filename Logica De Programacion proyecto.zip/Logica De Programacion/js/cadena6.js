function reemplazarA() {
      const texto = document.getElementById('texto').value;
      const res = document.getElementById('resultado');

      if (texto.trim() === '') {
        res.textContent = 'Por favor, ingresa un texto.';
        return;
      }

      const resultado = texto.replace(/a/gi, '@');
      res.textContent = `Texto modificado: ${resultado}`;
    }

    function limpiar() {
      document.getElementById('texto').value = '';
      document.getElementById('resultado').textContent = '';
    }