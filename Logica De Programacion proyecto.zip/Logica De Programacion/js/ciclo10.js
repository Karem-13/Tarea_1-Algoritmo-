function contarNumeros() {
      let contador = 0;
      let numero;

      while (true) {
        let entrada = prompt("Ingresa un número (0 para terminar):");
        if (entrada === null) break; // cancelar
        numero = parseFloat(entrada);

        if (isNaN(numero)) {
          alert("Por favor, ingresa un número válido.");
          continue;
        }

        if (numero === 0) break;

        contador++;
      }

      document.getElementById("res10").innerText = `Ingresaste ${contador} número(s) antes del 0.`;
    }

    function limpiarEjercicio10() {
      document.getElementById("res10").innerText = '';
    }