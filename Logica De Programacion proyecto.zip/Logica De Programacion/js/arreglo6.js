
    function mostrarCubos() {
      const numeros = [
        Number(document.getElementById('n1').value),
        Number(document.getElementById('n2').value),
        Number(document.getElementById('n3').value),
        Number(document.getElementById('n4').value),
        Number(document.getElementById('n5').value),
      ];

      if (numeros.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todos los campos correctamente.';
        return;
      }

      const cubos = numeros.map(n => `${n}³ = ${Math.pow(n, 3)}`);
      document.getElementById('resultado').innerHTML = cubos.join('<br>');
    }

    function limpiar() {
      for (let i = 1; i <= 5; i++) {
        document.getElementById('n' + i).value = '';
      }
      document.getElementById('resultado').textContent = '';
    }

