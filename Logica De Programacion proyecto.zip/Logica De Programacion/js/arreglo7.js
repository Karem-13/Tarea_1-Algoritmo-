    function mostrarTablas() {
      const numeros = [
        Number(document.getElementById('n1').value),
        Number(document.getElementById('n2').value),
        Number(document.getElementById('n3').value),
      ];

      if (numeros.some(isNaN)) {
        document.getElementById('resultado').textContent = 'Completa todos los campos correctamente.';
        return;
      }

      let salida = '';
      numeros.forEach(num => {
        salida += `<strong>Tabla del ${num}</strong><br>`;
        for (let i = 1; i <= 10; i++) {
          salida += `${num} x ${i} = ${num * i}<br>`;
        }
        salida += `<br>`;
      });

      document.getElementById('resultado').innerHTML = salida;
    }

    function limpiar() {
      document.getElementById('n1').value = '';
      document.getElementById('n2').value = '';
      document.getElementById('n3').value = '';
      document.getElementById('resultado').textContent = '';
    }
    