function mostrarPares() {
      let resultado = "";
      for (let i = 2; i <= 50; i += 2) {
        resultado += i + " ";
      }
      document.getElementById("res5").innerText = resultado;
    }

    function limpiarEjercicio5() {
      document.getElementById("res5").innerText = '';
    }