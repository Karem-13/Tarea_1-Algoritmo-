function limpiar(resId, inputId) {
      document.getElementById(resId).innerText = "";
      if (inputId) document.getElementById(inputId).value = "";
    }

    function mostrarDel1Al10() {
      let r = "";
      for (let i = 1; i <= 10; i++) r += i + " ";
      document.getElementById("res1").innerText = r;
    }
