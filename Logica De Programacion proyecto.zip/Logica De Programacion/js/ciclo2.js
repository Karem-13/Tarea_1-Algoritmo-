function tablaMultiplicar() {
      const num = parseInt(document.getElementById("num2").value);
      let resultado = '';
      for (let i = 1; i <= 10; i++) {
        resultado += `${num} × ${i} = ${num * i}<br>`;
      }
      document.getElementById("res2").innerHTML = resultado;
    }

    function limpiarEjercicio2() {
      document.getElementById("num2").value = '';
      document.getElementById("res2").innerHTML = '';
    }