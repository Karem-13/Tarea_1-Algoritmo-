 function contarLetra() {
      const texto = document.getElementById('texto').value.toLowerCase();
      const letra = document.getElementById('letra').value.toLowerCase();
      const res = document.getElementById('resultado');

      if (texto.trim() === '' || letra.trim() === '') {
        res.textContent = 'Por favor, completa ambos campos.';
        return;
      }

      if (letra.length !== 1) {
        res.textContent = 'Ingresa solo una letra.';
        return;
      }

      let contador = 0;
      for (let char of texto) {
        if (char === letra) contador++;
      }

      res.textContent = `La letra "${letra}" aparece ${contador} vez(veces).`;
    }

    function limpiar() {
      document.getElementById('texto').value = '';
      document.getElementById('letra').value = '';
      document.getElementById('resultado').textContent = '';
    }