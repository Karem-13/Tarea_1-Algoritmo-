function ejercicio6() {
            const nombre = document.getElementById('nombre6').value.trim();
            const genero = document.getElementById('genero6').value;
            const resultado = document.getElementById('resultado6');
            
            // Validar que se hayan ingresado los datos
            if (!nombre) {
                mostrarResultado('Por favor, ingresa tu nombre.', 'error', '⚠️');
                return;
            }
            
            if (!genero) {
                mostrarResultado('Por favor, selecciona tu género.', 'error', '⚠️');
                return;
            }
            
            // Generar saludo según el género
            let saludo;
            let icono;
            
            if (genero === 'M') {
                saludo = `¡Bienvenido, ${nombre}!`;
                icono = '👨';
            } else if (genero === 'F') {
                saludo = `¡Bienvenida, ${nombre}!`;
                icono = '👩';
            }
            
            mostrarResultado(saludo, 'success', icono);
        }
        
        function mostrarResultado(mensaje, tipo, icono) {
            const resultado = document.getElementById('resultado6');
            resultado.innerHTML = `<span class="greeting-icon">${icono}</span>${mensaje}`;
            resultado.className = `result ${tipo}`;
        }
        
        function limpiar() {
            document.getElementById('nombre6').value = '';
            document.getElementById('genero6').value = '';
            const resultado = document.getElementById('resultado6');
            resultado.innerHTML = '';
            resultado.className = 'result';
            
            // Enfocar el campo de nombre después de limpiar
            document.getElementById('nombre6').focus();
        }
        
        // Permitir envío con Enter
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('nombre6').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    ejercicio6();
                }
            });
            
            // Enfocar automáticamente el campo de nombre al cargar
            document.getElementById('nombre6').focus();
        });