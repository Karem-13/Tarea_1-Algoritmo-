function validarEdad() {
      const edad = parseInt(document.getElementById("edad").value);
      let mensaje = "";

      if (edad >= 0 && edad <= 12) {
        mensaje = "Eres un niño.";
      } else if (edad <= 17) {
        mensaje = "Eres un adolescente.";
      } else if (edad <= 59) {
        mensaje = "Eres un adulto.";
      } else if (edad >= 60) {
        mensaje = "Eres un adulto mayor.";
      } else {
        mensaje = "Edad inválida.";
      }

      document.getElementById("resultado").innerHTML = `<strong>Resultado:</strong> ${mensaje}`}

      function numeroMayor() {
      const n1 = parseFloat(document.getElementById("n1").value);
      const n2 = parseFloat(document.getElementById("n2").value);
      const n3 = parseFloat(document.getElementById("n3").value);
      const n4 = parseFloat(document.getElementById("n4").value);

      if (isNaN(n1) || isNaN(n2) || isNaN(n3) || isNaN(n4)) {
        document.getElementById("resultado2").textContent = "Por favor, ingresa los 4 números.";
        return;
      }

      const mayor = Math.max(n1, n2, n3, n4);
      document.getElementById("resultado2").textContent = `El número mayor es: ${mayor}`;
    }

    function limpiarCampos() {
      document.getElementById("n1").value = "";
      document.getElementById("n2").value = "";
      document.getElementById("n3").value = "";
      document.getElementById("n4").value = "";
      document.getElementById("resultado2").textContent = "Se mostrará el número mayor aquí.";
    }

    function estadoNota() {
  let nota = parseFloat(prompt("Ingresa tu nota:"));

  if (nota >= 7) {
    alert("¡Aprobado!");
  } else if (nota >= 5) {
    alert("Supletorio");
  } else {
    alert("Reprobado");
  }
}

function evaluarDia() {
  let dia = prompt("Ingresa un día de la semana:").toLowerCase();

  if (dia === "sábado" || dia === "sabado" || dia === "domingo") {
    alert("Es fin de semana");
  } else if (
    dia === "lunes" || dia === "martes" || dia === "miércoles" ||
    dia === "miercoles" || dia === "jueves" || dia === "viernes"
  ) {
    alert("Es entre semana");
  } else {
    alert("Día no válido");
  }
}

function evaluarTemperatura() {
  let temp = parseFloat(prompt("¿Qué temperatura hay? (°C)"));

  if (temp < 15) {
    alert("Hace frío ❄️");
  } else if (temp <= 25) {
    alert("Está templado 🌤️");
  } else {
    alert("Hace calor 🔥");
  }
}

function saludoGenero() {
  let nombre = prompt("Ingresa tu nombre:");
  let genero = prompt("¿Eres hombre o mujer?").toLowerCase();

  if (genero === "hombre") {
    alert("Bienvenido " + nombre);
  } else if (genero === "mujer") {
    alert("Bienvenida " + nombre);
  } else {
    alert("Género no reconocido");
  }
}

function saludoPorHora() {
  let hora = parseInt(prompt("¿Qué hora es? (0 a 23)"));

  if (hora >= 0 && hora <= 11) {
    alert("Buenos días ☀️");
  } else if (hora <= 17) {
    alert("Buenas tardes 🌤️");
  } else if (hora <= 23) {
    alert("Buenas noches 🌙");
  } else {
    alert("Hora inválida");
  }
}

function calcularBono() {
  let hijos = parseInt(prompt("¿Cuántos hijos tienes?"));
  let trabajo = prompt("¿Tienes trabajo? (sí/no)").toLowerCase();
  let bono = 0;

  if (hijos > 0 && trabajo === "sí") {
    bono = hijos * 50;
  } else if (hijos > 0 && trabajo === "no") {
    bono = hijos * 30;
  }

  alert("Tu bono es: $" + bono);
}

function descuentoCliente() {
  let tipo = prompt("Tipo de cliente (Normal o VIP):").toLowerCase();
  let gasto = parseFloat(prompt("¿Cuánto gastó?"));
  let descuento = 0;

  if (tipo === "vip" && gasto > 100) {
    descuento = gasto * 0.20;
  } else {
    descuento = gasto * 0.10;
  }

  let totalConDescuento = gasto - descuento;
  let totalConIva = totalConDescuento * 1.15;

  alert("Total con descuento e IVA: $" + totalConIva.toFixed(2));
}
function calcularCompra() {
  let tieneMembresia = prompt("¿Tienes membresía? (sí/no)").toLowerCase();
  let compra = parseFloat(prompt("¿Cuál es el valor de tu compra?"));
  let descuento, iva;

  if (tieneMembresia === "sí" && compra > 50) {
    descuento = compra * 0.30;
    iva = (compra - descuento) * 0.15;
  } else {
    descuento = compra * 0.05;
    iva = (compra - descuento) * 0.10;
  }

  let total = (compra - descuento) + iva;
  alert("Total con descuento e IVA: $" + total.toFixed(2));
}
