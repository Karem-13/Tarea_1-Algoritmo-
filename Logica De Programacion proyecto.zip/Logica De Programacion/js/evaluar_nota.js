function evaluarNota() {
  const nota = parseFloat(document.getElementById("nota").value);
  const resultado = document.getElementById("resultadoNota");

  if (isNaN(nota) || nota < 0 || nota > 10) {
    resultado.textContent = "⚠️ Ingresa una nota válida entre 0 y 10.";
    return;
  }

  if (nota >= 7) {
    resultado.textContent = "✅ ¡Aprobado!";
  } else if (nota >= 5) {
    resultado.textContent = "⚠️ Supletorio.";
  } else {
    resultado.textContent = "❌ Reprobado.";
  }
}

function limpiarNota() {
  document.getElementById("nota").value = "";
  document.getElementById("resultadoNota").textContent = "Aquí se mostrará el resultado.";
}
