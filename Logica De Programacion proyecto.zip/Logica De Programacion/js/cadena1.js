 function contarLetras() {
      const palabra = document.getElementById('palabra').value.trim();
      const res = document.getElementById('resultado');
      if (palabra === '') {
        res.textContent = 'Por favor, ingresa una palabra.';
        return;
      }
      res.textContent = `La palabra tiene ${palabra.length} letra(s).`;
    }

    function limpiar() {
      document.getElementById('palabra').value = '';
      document.getElementById('resultado').textContent = '';
    }