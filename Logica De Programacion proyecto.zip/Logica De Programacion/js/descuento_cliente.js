function descuentoCliente() {
  let tipo = prompt("Tipo de cliente (Normal o VIP):").toLowerCase();
  let gasto = parseFloat(prompt("¿Cuánto gastó?"));
  let descuento = 0;

  if (tipo === "vip" && gasto > 100) {
    descuento = gasto * 0.20;
  } else {
    descuento = gasto * 0.10;
  }

  let totalConDescuento = gasto - descuento;
  let totalConIva = totalConDescuento * 1.15;

  alert("Total con descuento e IVA: $" + totalConIva.toFixed(2));
}